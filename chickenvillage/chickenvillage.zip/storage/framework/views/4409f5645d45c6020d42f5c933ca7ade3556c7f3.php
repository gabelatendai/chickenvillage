<?php
/**
 * Created by PhpStorm.
 * User: gabela
 * Date: 26/10/2018
 * Time: 22:16
 */
?>



<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>">
    <br>  <br>  <br>
    <div class="content-wrapper">

        <!-- Stunning Header -->


                <h1 class="page-header text--center"><?php echo e($news->title); ?></h1>

        <div class="container">
            <div class="row medium-padding120">
                <main class="main">
                    <div class="col-lg-10 col-lg-offset-1">
                        <article class="hentry post post-standard-details">

                                <div class="post-thumb">
                                <img  class="img-thumbnail" src="<?php echo e($news->image); ?>" alt="seo">
                            </div>

                            <div class="post__content">


                                <div class="post-additional-info">



                                    <span class="post__date">

                                <i class="seoicon-clock"></i>

                                <time class="published" datetime="2016-03-20 12:00:00">
                                   <?php echo e($news->created_at->toFormattedDateString()); ?>

                                </time>

                            </span>

                                    <span class="category">
                                <i class="seoicon-tags"></i>
                                <a href="#"><?php echo e($news->category); ?></a>

                            </span>

                                </div>

                                <div class="post__content-info">
<?php echo $news->msg; ?>

                            </div>


                        <div class="pagination-arrow">
                            <?php if($prev): ?>
                                <a href="<?php echo e(route('page-news',['slug'=>$prev->slug])); ?>" class="btn-next-wrap">
                                    <div class="btn-content">
                                        <div class="btn-content-title">Next Post</div>
                                        <p class="btn-content-subtitle"><?php echo e($prev->title); ?></p>
                                    </div>
                                    <svg class="btn-next">
                                        <use xlink:href="#arrow-right"></use>
                                    </svg>
                                </a>
                            <?php endif; ?>
<?php if($next): ?>
                            <a href="<?php echo e(route('page-news',['slug'=>$next->slug])); ?>" class="btn-prev-wrap">
                                <svg class="btn-prev">
                                    <use xlink:href="#arrow-left"></use>
                                </svg>
                                <div class="btn-content">
                                    <div class="btn-content-title">Previous Post</div>
                                    <p class="btn-content-subtitle"><?php echo e($next->title); ?></p>
                                </div>
                            </a>
<?php endif; ?>

                        </div>

                    </div>

                    <!-- End Sidebar-->
                        </article></div>
                </main>
            </div>
        </div>


        <!-- End Subscribe Form -->

    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>