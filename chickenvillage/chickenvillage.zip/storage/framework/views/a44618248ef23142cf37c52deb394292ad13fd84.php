 

<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">

<div class=" panel panel-heading ">
 Users
</div>
<div class=" panel panel-body ">
<table cellpadding="0" cellspacing="0" border="0" class="table table-hoover table-striped table-bordered" id="example">
    <thead>
    <tr>
        <th>No</th>
        <th>Image</th>
        <th>Name</th>
         <th>Permissions</th>
         <th>Delete</th>
    </tr>
    </thead>
     <?php if($users->count()>0): ?>
 <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tbody>
     <tr> <td> <?php echo e($user->id); ?></td>
               <td> <?php echo e($user->email); ?></td>
               <td> <?php echo e($user->name); ?></td>
               <td>
                   <?php if($user->admin): ?>
                 <a href="<?php echo e(route('admin.remove',['id'=> $user->id])); ?>" style="margin-bottom:5px;" class="btn btn-xs btn-danger">
                                                            Remove Permissions</a>
                       <?php else: ?>
                       <a href="<?php echo e(route('admin.permissions',['id'=> $user->id])); ?>" style="margin-bottom:5px;" class="btn btn-xs btn-danger">
                         Make Admin</a>

                   <?php endif; ?>
                </td>


                  <td>  <a href="<?php echo e(route('admin.delete',['id'=> $user->id])); ?>" style="margin-bottom:5px;" class="btn btn-xs btn-danger">

                                 Delete</a>
                                  </td>
         </td>
     </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php else: ?>
                  <tr>
                          <th colspan="6" class="text-center">No Published  Posts </th>

                      </tr>
                  <?php endif; ?>

     </tbody></table>



        </div>
    </div>
</div>
</body>
</html>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>