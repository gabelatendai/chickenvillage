<?php $__env->startSection('content'); ?>
<!-- Page Title #1
============================================= -->
<section id="page-title" class="page-title bg-overlay bg-parallax bg-overlay-gradient">
    <div class="bg-section">
        <img src="<?php echo e(asset('assets/images/menu/menu-board/7.jpg')); ?>" alt="Background" />
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="title title-1 text-center">
                    <div class="title--content">
                        <div class="title--subtitle">Don't miss</div>
                        <div class="title--heading">
                            <h1>Our News & Events</h1>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo e('/'); ?>">Home</a>
                        </li>
                        <li><a href="">blog</a>
                        </li>
                        <li class="active">blog carousel</li>
                    </ol>
                    <div class="divider--shape-1down"></div>
                </div>
                <!-- .title end -->
            </div>
            <!-- .col-md-12 end -->
        </div>
        <!-- .row end -->
    </div>
    <!-- .container end -->
</section>
<!-- #page-title end -->

<div class="clearfix pt-150 bg-gray"></div>

<!-- Blog Carousel
============================================= -->
<section id="blog2" class="blog blog-carousel pb-100">
    <div class="container">
        <div class="row clearfix">
            <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2">
                <div class="heading heading-1 mb-50 text--center">
                    <p class="heading--subtitle">Don’t miss</p>
                    <h2 class="heading--title mb-0">Our News & Events</h2>
                    <div class="divider--shape-4"></div>
                </div>
            </div>
            <!-- .col-md-8 end -->
        </div>
        <!-- .row end -->
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="carousel carousel-dots" data-slide="3" data-slide-rs="2" data-autoplay="true" data-nav="false" data-dots="true" data-space="0" data-loop="true" data-speed="800">

<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-entry">

                        <div class="entry--content">
                            <div class="entry--meta">
                                <span class="entry--date"><?php echo e($new->created_at); ?></span> / <span><a href="#">Fall</a> , <a href="#">Side Dish</a></span>
                            </div>
                            <div class="entry--title">
                                <h4><a href="<?php echo e(route('page-news',['slug'=>$new->slug])); ?>"><?php echo e($new->title); ?></a></h4>
                            </div>
                            <div class="entry--img">
                                <a href="#">
								<img src="<?php echo e($new->image); ?>" alt="entry image"/>
							</a>
                            </div>
                            <div class="entry--bio">
                                <?php echo e(str_limit($new->msg, 40)); ?>     </div>
                        </div>
                        <!-- .entry-content end -->
                    </div>
                    <!-- .blog-entry end -->

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <!-- .carousel end -->
            </div>
            <!-- .col-md-6 end -->
        </div>
        <!-- .row end -->
    </div>
    <!-- .container end -->
</section>
<!-- #blog end -->

<div class="clearfix pt-150 bg-gray"></div>

<!-- Blog Carousel
============================================= -->
<section id="blog" class="blog blog-carousel pb-100">
    <div class="container">
        <div class="row clearfix">
            <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2">
                <div class="heading heading-1 mb-50 text--center">
                    <p class="heading--subtitle">Don’t miss</p>
                    <h2 class="heading--title mb-0">Our News & Events</h2>
                    <div class="divider--shape-4"></div>
                </div>
            </div>
            <!-- .col-md-8 end -->
        </div>
        <!-- .row end -->
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="carousel carousel-dots" data-slide="4" data-slide-rs="2" data-autoplay="true" data-nav="false" data-dots="true" data-space="0" data-loop="true" data-speed="800">
                    <!-- Blog Entry #1 -->
                    <?php $__currentLoopData = $nes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-entry">

                        <div class="entry--content">
                            <div class="entry--meta">
                                <span class="entry--date"><?php echo e($ne->created_at); ?></span> / <span><a href="#">Fall</a></span>
                            </div>
                            <div class="entry--title">
                                <h4><a href="#"><?php echo e($ne->title); ?></a></h4>
                            </div>
                            <div class="entry--img">
                                <a href="#">
								<img src="<?php echo e($ne->image); ?>" alt="entry image"/>
							</a>
                            </div>
                            <div class="entry--bio">
                                <?php echo e(str_limit($new->msg, 100)); ?>  </div>
                        </div>
                        <!-- .entry-content end -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- .blog-entry end -->
                    <!-- .blog-entry end -->
                </div>
                <!-- .carousel end -->
            </div>
            <!-- .col-md-6 end -->
        </div>
        <!-- .row end -->
    </div>
    <!-- .container end -->
</section>
<!-- #blog end -->

<div class="clearfix pt-150 bg-gray"></div>
<!-- footer#1
============================================= --><?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>