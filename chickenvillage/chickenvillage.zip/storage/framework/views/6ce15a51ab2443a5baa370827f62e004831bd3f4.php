<?php $__env->startSection('content'); ?>

<!-- Page Title #1
============================================= -->
<section id="page-title" class="page-title bg-overlay bg-parallax bg-overlay-gradient">
    <div class="bg-section">
        <img src="<?php echo e(asset('assets/images/menu/menu-board/16.jpg')); ?>" alt="Background" />
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="title title-1 text-center">
                    <div class="title--content">
                        <div class="title--subtitle">Fresh, Tasty Meals</div>
                        <div class="title--heading">
                            <h1>Discover Our Menu</h1>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo e('/'); ?>">Home</a>
                        </li>
                        <li><a href="<?php echo e('/'); ?>">menu</a>
                        </li>
                        <li class="active">Gallery</li>
                    </ol>
                    <div class="divider--shape-1down"></div>
                </div>
                <!-- .title end -->
            </div>
            <!-- .col-md-12 end -->
        </div>
        <!-- .row end -->
    </div>
    <!-- .container end -->
</section>
<!-- #page-title end -->

<!-- Menu Gallery
============================================= -->
<section id="menuBoard" class="pb-90">
    <div class="container">
        <div class="row clearfix">
            <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2">
                <div class="heading heading-1 mb-50 text--center">
                    <p class="heading--subtitle">Start Eating Better</p>
                    <h2 class="heading--title mb-0">Daily New Fresh Meals</h2>
                    <div class="divider--shape-4"></div>
                    <p class="heading--desc">Chicken Village has the perfect place to enjoy fine food and great cocktails with excellent service, in comfortable atmospheric surroundings. We have a soft dining room, combined with an open kitchen, coffee take out bar and alovely awesome on site coffee roastery.</p>
                </div>
            </div>
            <!-- .col-md-8 end -->
        </div>
        <!-- .row end -->
    </div>
    <!-- .container end -->
    <div class="container-fluid tabs">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs">
                    <li><a href="#breakfast" data-toggle="tab">Breakfast</a></li>
                    <li class="active"><a href="#lunch" data-toggle="tab">Lunch</a></li>
                    <li><a href="#dinner" data-toggle="tab">Dinner</a></li>
                    <li><a href="#dessert" data-toggle="tab">Dessert</a></li>
                    <li><a href="#drinks" data-toggle="tab">Drinks</a></li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane fade" id="breakfast">
                        <!-- Menu #7
============================================= -->
                        <div class="menu menu-board text-center">
                            <div class="row">
                                <div class="dishes-wrapper">
                                    <?php $__currentLoopData = $breakfast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breakf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-xs-12 col-sm-12 col-md-6">
                                            <div class="row dish-panel">
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class=" dish--content">
                                                        <div class="dish--tag">Chef Selection</div>
                                                        <span class="dish--price">$<?php echo e($breakf->price); ?></span>
                                                        <h3 class="dish--title"><?php echo e($breakf->food_name); ?></h3>
                                                        <div class="divider--shape-4"></div>
                                                        <p class="dish--desc"><?php echo e($breakf->description); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6 ">
                                                    <div class="dish--img">
                                                        <div class="divider--shape-left"></div>
                                                        <img src="<?php echo e($breakf->image); ?>" alt="dish img">
                                                        <div class="dish--overlay">
                                                            <a class="dish-popup" data-toggle="modal" data-target="#dishPopup9"><i class="fa fa-search-plus"></i></a>
                                                            <div class="modal fade" tabindex="-1" role="dialog" id="dishPopup9">
                                                                <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-body">
                                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                                                                            <div class="row reservation">
                                                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                                                    <div class="popup--img">
                                                                                        <img src="<?php echo e($breakf->image); ?>" alt="dish popup">
                                                                                        <div class="img-popup-overlay">
                                                                                            <div class="popup--price">$<?php echo e($breakf->price); ?></div>
                                                                                            <h3 class="popup--title"><?php echo e($breakf->food_name); ?></h3>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <!-- .col-md-12 end -->
                                                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                                                    <div class="content-popup">
                                                                                        <p> <?php echo e($breakf->description); ?></p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!-- .row end -->

                                                                        </div>
                                                                    </div>
                                                                    <!-- /.modal-content -->
                                                                </div>
                                                                <!-- /.modal-dialog -->
                                                            </div>
                                                            <!-- /.modal -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <!-- .row end -->
                            </div>
                            <!-- .row end -->
                        </div>
                    </div>
                    <!-- .tab-pane end -->
                    <div class="tab-pane fade in active" id="lunch">
                        <!-- Menu #7
============================================= -->
                        <div class="menu menu-board text-center">
                            <div class="row">
                                <div class="dishes-wrapper">
                                    <?php $__currentLoopData = $lunch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lunchy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-xs-12 col-sm-12 col-md-6">
                                            <div class="row dish-panel">
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class=" dish--content">
                                                        <div class="dish--tag">Chef Selection</div>
                                                        <span class="dish--price">$<?php echo e($lunchy->price); ?></span>
                                                        <h3 class="dish--title"><?php echo e($lunchy->food_name); ?></h3>
                                                        <div class="divider--shape-4"></div>
                                                        <p class="dish--desc"><?php echo e($lunchy->description); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6 ">
                                                    <div class="dish--img">
                                                        <div class="divider--shape-left"></div>
                                                        <img src="<?php echo e($lunchy->image); ?>" alt="dish img">
                                                        <div class="dish--overlay">
                                                            <a class="dish-popup" data-toggle="modal" data-target="#dishPopup9"><i class="fa fa-search-plus"></i></a>
                                                            <div class="modal fade" tabindex="-1" role="dialog" id="dishPopup9">
                                                                <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-body">
                                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                                                                            <div class="row reservation">
                                                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                                                    <div class="popup--img">
                                                                                        <img src="<?php echo e($lunchy->image); ?>" alt="dish popup">
                                                                                        <div class="img-popup-overlay">
                                                                                            <div class="popup--price">$<?php echo e($lunchy->price); ?></div>
                                                                                            <h3 class="popup--title"><?php echo e($lunchy->food_name); ?></h3>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <!-- .col-md-12 end -->
                                                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                                                    <div class="content-popup">
                                                                                        <p> <?php echo e($lunchy->description); ?></p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!-- .row end -->

                                                                        </div>
                                                                    </div>
                                                                    <!-- /.modal-content -->
                                                                </div>
                                                                <!-- /.modal-dialog -->
                                                            </div>
                                                            <!-- /.modal -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <!-- .row end -->
                            </div>
                            <!-- .row end -->
                        </div>
                    </div>
                    <!-- .tab-pane end -->
                    <div class="tab-pane fade" id="dinner">
                        <!-- Menu #7
============================================= -->

                        <div class="menu menu-board text-center">

                            <div class="row">

                                <div class="dishes-wrapper">
                                    <!-- Dish #1 --> <?php $__currentLoopData = $supper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dinner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-xs-12 col-sm-12 col-md-6">
                                            <div class="row dish-panel">
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class=" dish--content">
                                                        <div class="dish--tag">Chef Selection</div>
                                                        <span class="dish--price">$<?php echo e($dinner->price); ?></span>
                                                        <h3 class="dish--title"><?php echo e($dinner->food_name); ?></h3>
                                                        <div class="divider--shape-4"></div>
                                                        <p class="dish--desc"><?php echo e($dinner->description); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6 ">
                                                    <div class="dish--img">
                                                        <div class="divider--shape-left"></div>
                                                        <img src="<?php echo e($dinner->image); ?>" alt="dish img">
                                                        <div class="dish--overlay">
                                                            <a class="dish-popup" data-toggle="modal" data-target="#dishPopup9"><i class="fa fa-search-plus"></i></a>
                                                            <div class="modal fade" tabindex="-1" role="dialog" id="dishPopup9">
                                                                <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-body">
                                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                                                                            <div class="row reservation">
                                                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                                                    <div class="popup--img">
                                                                                        <img src="<?php echo e($dinner->image); ?>" alt="dish popup">
                                                                                        <div class="img-popup-overlay">
                                                                                            <div class="popup--price">$<?php echo e($dinner->price); ?></div>
                                                                                            <h3 class="popup--title"><?php echo e($dinner->food_name); ?></h3>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <!-- .col-md-12 end -->
                                                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                                                    <div class="content-popup">
                                                                                        <p> <?php echo e($dinner->description); ?></p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!-- .row end -->

                                                                        </div>
                                                                    </div>
                                                                    <!-- /.modal-content -->
                                                                </div>
                                                                <!-- /.modal-dialog -->
                                                            </div>
                                                            <!-- /.modal -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <!-- .row end -->
                            </div>

                            <!-- .row end -->
                        </div>

                    </div>
                    <!-- .tab-pane end -->
                    <div class="tab-pane fade" id="dessert">
                        <!-- Menu #7
============================================= -->
                        <div class="menu menu-board text-center">
                            <div class="row">
                                <div class="dishes-wrapper">
                                    <!-- Dish #1 -->
                                    <!-- Dish #1 --> <?php $__currentLoopData = $desert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deserty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-xs-12 col-sm-12 col-md-6">
                                            <div class="row dish-panel">
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class=" dish--content">
                                                        <div class="dish--tag">Chef Selection</div>
                                                        <span class="dish--price">$<?php echo e($deserty->price); ?></span>
                                                        <h3 class="dish--title"><?php echo e($deserty->food_name); ?></h3>
                                                        <div class="divider--shape-4"></div>
                                                        <p class="dish--desc"><?php echo e($deserty->description); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6 ">
                                                    <div class="dish--img">
                                                        <div class="divider--shape-left"></div>
                                                        <img src="<?php echo e($deserty->image); ?>" alt="dish img">
                                                        <div class="dish--overlay">
                                                            <a class="dish-popup" data-toggle="modal" data-target="#dishPopup9"><i class="fa fa-search-plus"></i></a>
                                                            <div class="modal fade" tabindex="-1" role="dialog" id="dishPopup9">
                                                                <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-body">
                                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                                                                            <div class="row reservation">
                                                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                                                    <div class="popup--img">
                                                                                        <img src="<?php echo e($deserty->image); ?>" alt="dish popup">
                                                                                        <div class="img-popup-overlay">
                                                                                            <div class="popup--price">$<?php echo e($deserty->price); ?></div>
                                                                                            <h3 class="popup--title"><?php echo e($deserty->food_name); ?></h3>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <!-- .col-md-12 end -->
                                                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                                                    <div class="content-popup">
                                                                                        <p> <?php echo e($deserty->description); ?></p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!-- .row end -->

                                                                        </div>
                                                                    </div>
                                                                    <!-- /.modal-content -->
                                                                </div>
                                                                <!-- /.modal-dialog -->
                                                            </div>
                                                            <!-- /.modal -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <!-- .row end -->
                            </div>
                            <!-- .row end -->
                        </div>
                    </div>
                    <!-- .tab-pane end -->
                    <div class="tab-pane fade" id="drinks">
                        <!-- Menu #7
============================================= -->
                        <div class="menu menu-board text-center">
                            <div class="row">
                                <div class="dishes-wrapper">
                                    <!-- Dish #1 --> <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-xs-12 col-sm-12 col-md-6">
                                            <div class="row dish-panel">
                                                <div class="col-xs-12 col-sm-6 col-md-6">
                                                    <div class=" dish--content">
                                                        <div class="dish--tag">Chef Selection</div>
                                                        <span class="dish--price">$<?php echo e($drink->price); ?></span>
                                                        <h3 class="dish--title"><?php echo e($drink->food_name); ?></h3>
                                                        <div class="divider--shape-4"></div>
                                                        <p class="dish--desc"><?php echo e($drink->description); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-6 ">
                                                    <div class="dish--img">
                                                        <div class="divider--shape-left"></div>
                                                        <img src="<?php echo e($drink->image); ?>" alt="dish img">
                                                        <div class="dish--overlay">
                                                            <a class="dish-popup" data-toggle="modal" data-target="#dishPopup9"><i class="fa fa-search-plus"></i></a>
                                                            <div class="modal fade" tabindex="-1" role="dialog" id="dishPopup9">
                                                                <div class="modal-dialog" role="document">
                                                                    <div class="modal-content">
                                                                        <div class="modal-body">
                                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                                                                            <div class="row reservation">
                                                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                                                    <div class="popup--img">
                                                                                        <img src="<?php echo e($drink->image); ?>" alt="dish popup">
                                                                                        <div class="img-popup-overlay">
                                                                                            <div class="popup--price">$<?php echo e($drink->price); ?></div>
                                                                                            <h3 class="popup--title"><?php echo e($drink->food_name); ?></h3>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <!-- .col-md-12 end -->
                                                                                <div class="col-xs-12 col-sm-12 col-md-12">
                                                                                    <div class="content-popup">
                                                                                        <p> <?php echo e($drink->description); ?></p>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <!-- .row end -->

                                                                        </div>
                                                                    </div>
                                                                    <!-- /.modal-content -->
                                                                </div>
                                                                <!-- /.modal-dialog -->
                                                            </div>
                                                            <!-- /.modal -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <!-- .row end -->
                            </div>
                            <!-- .row end -->
                        </div>
                    </div>
                    <!-- .tab-pane end -->
                </div>
                <!-- .tabs-content end -->
            </div>
            <!-- .col-md-12 end -->
        </div>
        <!-- .row end -->
    </div>
    <!-- .container end -->
    <div class="container">
        <div class="row clearfix">
            <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2 text--center">
                <a class="btn btn--primary btn--bordered btn--rounded btn--lg mt-50" href="#">Discover Full Menu</a>
            </div>
            <!-- .col-md-8 end -->
        </div>
        <!-- .row end -->
    </div>
    <!-- .container end -->
</section>
<!-- #menuGallery end -->

<!-- footer#1
============================================= -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>