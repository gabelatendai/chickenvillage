<?php $__env->startSection('content'); ?>

    <div class="panel panel-default">
                <div class="panel-heading">Company Information</div>

                <div class="panel-body">
                 <table cellpadding="0" cellspacing="0" border="0" class="table table-hoover table-striped table-bordered" id="example">
                     <thead>
                     <tr>
                         <th>Logo</th>
                         <th>Name</th>
                         <th> Phone Number</th>
                         <th>Email</th>
                         <th>Description</th>
                         <th> Bio Information</th>

                          <th>Edit</th>
                     </tr>
                     </thead>

                  <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tbody>
                      <tr><td><img src=" <?php echo e($about ->image); ?>" width="100" height="80" class="img-thumbnail"></td>
                          <td> <?php echo e($about ->name); ?></td>
                          <td> <?php echo e($about->pnumber); ?></td>
                          <td> <?php echo e($about->email); ?></td>
                                <td> <?php echo e($about->description); ?></td>
                          <td> <?php echo e($about->about); ?></td>
                                 <td> <a href="<?php echo e(route('about.edit',['id'=> $about->id])); ?>" style="margin-bottom:5px;" class="btn btn-xs btn-success">
                                 Edit</a> </td>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tr>
                      </tbody></table>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>