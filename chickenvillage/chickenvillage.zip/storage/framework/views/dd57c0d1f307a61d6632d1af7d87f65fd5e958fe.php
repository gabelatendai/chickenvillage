<?php $__env->startSection('content'); ?>

    <a href="<?php echo e('/banners/create'); ?>" class="pull-right btn btn-info btn-xs"> <h3>Add New Banner</h3></a>
    <div class="panel panel-default">
                <div class="panel-heading">Products</div>

                <div class="panel-body">
                 <table cellpadding="0" cellspacing="0" border="0" class="table table-hoover table-striped table-bordered" id="example">
                     <thead>
                     <tr>
                         <th>Image</th>
                         <th> Slide Main Headline</th>
                         <th> Slide Sub Headline</th>
                         <th>Editing</th>
                          <th>Deleting</th>
                     </tr>
                     </thead>

                  <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tbody>
                      <tr> <td> <img src="<?php echo e($banner ->image); ?>" width="40px" height="40px>"></td>
                          <td> <?php echo e($banner->headline); ?></td>
                          <td> <?php echo e($banner->sub_headline); ?></td>

                                 <td> <a href="<?php echo e(route('banners.edit',['id'=> $banner->id])); ?>" style="margin-bottom:5px;" class="btn btn-xs btn-success">
                                 Edit</a> </td>
                          <td> <a href="<?php echo e(route('banners.destroy',['id'=> $banner->id])); ?>" style="margin-bottom:5px;" class="btn btn-xs btn-danger">
                                  Delete</a> </td>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </tr>
                      </tbody></table>
                         <div class="text-center">
                             <?php echo e($banners->links()); ?>

                         </div>
                </div>
    </div></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>